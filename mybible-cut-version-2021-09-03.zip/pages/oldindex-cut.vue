<template>
  <div class="flex flex-col w-auto m-auto justify-center p-10">
    <table class="table-fixed border-black border-0">
      <tr class="text-center">
        <th class="w-1/3 border">舊 約 全 書</th>
        <th class="w-1/3 border">旧 约 全 书</th>
        <th class="w-1/3 border">The Old Testament</th>
      </tr>

      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Genesis&ver=cut">創 世 紀</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Genesis&ver=cus">创 世 纪</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Genesis&ver=basicenglish">Genesis</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Exodus&ver=cut">出 埃 及 記</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Exodus&ver=cus">出 埃 及 记</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Exodus&ver=basicenglish">Exodus</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Leviticus&ver=cut">利 未 記</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Leviticus&ver=cus">利 未 记</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Leviticus&ver=basicenglish">Leviticus</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Numbers&ver=cut">民 數 記</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Numbers&ver=cus">民 数 记</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Numbers&ver=basicenglish">Numbers</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Deuteronomy&ver=cut">申 命 記</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Deuteronomy&ver=cus">申 命 记</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Deuteronomy&ver=basicenglish">Deuteronomy</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Joshua&ver=cut">約 書 亞 記</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Joshua&ver=cus">约 书 亚 记</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Joshua&ver=basicenglish">Joshua</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Judges&ver=cut">士 師 記</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Judges&ver=cus">士 师 记</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Judges&ver=basicenglish">Judges</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Ruth&ver=cut">路 得 記</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Ruth&ver=cus">路 得 记</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Ruth&ver=basicenglish">Ruth</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=1Samuel&ver=cut">撒 母 耳 記 上</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1Samuel&ver=cus">撒 母 耳 记 上</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1Samuel&ver=basicenglish">1 Samuel</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=2Samuel&ver=cut">撒 母 耳 記 下</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2Samuel&ver=cus">撒 母 耳 记 下</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2Samuel&ver=basicenglish">2 Samuel</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=1Kings&ver=cut">列 王 記 上</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1Kings&ver=cus">列 王 记 上</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1Kings&ver=basicenglish">1 Kings</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=2Kings&ver=cut">列 王 記 下</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2Kings&ver=cus">列 王 记 下</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2Kings&ver=basicenglish">2 Kings</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=1Chronicles&ver=cut">歷 代 志 上</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1Chronicles&ver=cus">历 代 志 上</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1Chronicles&ver=basicenglish">1 Chronicles</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=2Chronicles&ver=cut">歷 代 志 下</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2Chronicles&ver=cus">历 代 志 下</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2Chronicles&ver=basicenglish">2 Chronicles</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Ezra&ver=cut">以 斯 拉 記</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Ezra&ver=cus">以 斯 拉 记</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Ezra&ver=basicenglish">Ezra</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Nehemiah&ver=cut">尼 希 米 記</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Nehemiah&ver=cus">尼 希 米 记</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Nehemiah&ver=basicenglish">Nehemiah</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Esther&ver=cut">以 斯 帖 記</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Esther&ver=cus">以 斯 帖 记</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Esther&ver=basicenglish">Esther</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Job&ver=cut">約 伯 記</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Job&ver=cus">约 伯 记</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Job&ver=basicenglish">Job</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Psalms&ver=cut">詩 篇</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Psalms&ver=cus">诗 篇</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Psalms&ver=basicenglish">Psalms</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Proverbs&ver=cut">箴 言</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Proverbs&ver=cus">箴 言</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Proverbs&ver=basicenglish">Proverbs</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Ecclesiastes&ver=cut">傳 道 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Ecclesiastes&ver=cus">传 道 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Ecclesiastes&ver=basicenglish">Ecclesiastes</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=SongofSongs&ver=cut">雅 歌</a></td>
        <td class="border"><a href="/new/thecontent?thebk=SongofSongs&ver=cus">雅 歌</a></td>
        <td class="border"><a href="/new/thecontent?thebk=SongofSongs&ver=basicenglish">Song of Songs</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Isaiah&ver=cut">以 賽 亞 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Isaiah&ver=cus">以 赛 亚 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Isaiah&ver=basicenglish">Isaiah</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Jeremiah&ver=cut">耶 利 米 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Jeremiah&ver=cus">耶 利 米 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Jeremiah&ver=basicenglish">Jeremiah</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Lamentations&ver=cut">耶 利 米 哀 歌</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Lamentations&ver=cus">耶 利 米 哀 歌</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Lamentations&ver=basicenglish">Lamentations</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Ezekiel&ver=cut">以 西 結 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Ezekiel&ver=cus">以 西 结 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Ezekiel&ver=basicenglish">Ezekiel</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Daniel&ver=cut">但 以 理 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Daniel&ver=cus">但 以 理 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Daniel&ver=basicenglish">Daniel</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Hosea&ver=cut">何 西 阿 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Hosea&ver=cus">何 西 阿 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Hosea&ver=basicenglish">Hosea</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Joel&ver=cut">約 珥 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Joel&ver=cus">约 珥 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Joel&ver=basicenglish">Joel</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Amos&ver=cut">阿 摩 司 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Amos&ver=cus">阿 摩 司 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Amos&ver=basicenglish">Amos</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Obadiah&ver=cut">俄 巴 底 亞 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Obadiah&ver=cus">俄 巴 底 亚 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Obadiah&ver=basicenglish">Obadiah</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Jonah&ver=cut">約 拿 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Jonah&ver=cus">约 拿 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Jonah&ver=basicenglish">Jonah</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Micah&ver=cut">彌 迦 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Micah&ver=cus">弥 迦 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Micah&ver=basicenglish">Micah</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Nahum&ver=cut">那 鴻 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Nahum&ver=cus">那 鸿 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Nahum&ver=basicenglish">Nahum</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Habakkuk&ver=cut">哈 巴 谷 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Habakkuk&ver=cus">哈 巴 谷 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Habakkuk&ver=basicenglish">Habakkuk</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Zephaniah&ver=cut">西 番 雅 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Zephaniah&ver=cus">西 番 雅 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Zephaniah&ver=basicenglish">Zephaniah</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Haggai&ver=cut">哈 該 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Haggai&ver=cus">哈 该 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Haggai&ver=basicenglish">Haggai</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Zechariah&ver=cut">撒 迦 利 亞 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Zechariah&ver=cus">撒 迦 利 亚 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Zechariah&ver=basicenglish">Zechariah</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Malachi&ver=cut">瑪 拉 基 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Malachi&ver=cus">玛 拉 基 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Malachi&ver=basicenglish">Malachi</a></td>
      </tr>

    </table>
  </div>
</template>

<script>
export default {}
</script>

<style>
</style>