<template>
  <div class="flex flex-col w-auto m-auto justify-center p-10">
    <table class="table-fixed border-black border-0">
      <tr class="text-center">
        <th class="w-1/3 border">新 約 全 書</th>
        <th class="w-1/3 border">新 约 全 书</th>
        <th class="w-1/3 border">The New Testament</th>
      </tr>

      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Matthew&ver=cut">馬 太 福 音</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Matthew&ver=cus">马 太 福 音</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Matthew&ver=basicenglish">Matthew</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Mark&ver=cut">馬 可 福 音</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Mark&ver=cus">马 可 福 音</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Mark&ver=basicenglish">Mark</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Luke&ver=cut">路 加 福 音</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Luke&ver=cus">路 加 福 音</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Luke&ver=basicenglish">Luke</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=John&ver=cut">約 翰 福 音</a></td>
        <td class="border"><a href="/new/thecontent?thebk=John&ver=cus">约 翰 福 音</a></td>
        <td class="border"><a href="/new/thecontent?thebk=John&ver=basicenglish">John</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Acts&ver=cut">使 徒 行 傳</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Acts&ver=cus">使 徒 行 传</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Acts&ver=basicenglish">Acts</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Romans&ver=cut">羅 馬 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Romans&ver=cus">罗 马 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Romans&ver=basicenglish">Romans</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=1Corinthians&ver=cut">哥 林 多 前 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1Corinthians&ver=cus">哥 林 多 前 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1Corinthians&ver=basicenglish">1 Corinthians</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=2Corinthians&ver=cut">哥 林 多 後 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2Corinthians&ver=cus">哥 林 多 后 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2Corinthians&ver=basicenglish">2 Corinthians</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Galatians&ver=cut">加 拉 太 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Galatians&ver=cus">加 拉 太 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Galatians&ver=basicenglish">Galatians</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Ephesians&ver=cut">以 弗 所 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Ephesians&ver=cus">以 弗 所 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Ephesians&ver=basicenglish">Ephesians</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Philippians&ver=cut">腓 立 比 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Philippians&ver=cus">腓 立 比 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Philippians&ver=basicenglish">Philippians</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Colossians&ver=cut">歌 羅 西 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Colossians&ver=cus">歌 罗 西 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Colossians&ver=basicenglish">Colossians</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=1Thessalonians&ver=cut">帖 撒 羅 尼 迦 前 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1Thessalonians&ver=cus">帖 撒 罗 尼 迦 前 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1Thessalonians&ver=basicenglish">1 Thessalonians</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=2Thessalonians&ver=cut">帖 撒 羅 尼 迦 後 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2Thessalonians&ver=cus">帖 撒 罗 尼 迦 后 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2Thessalonians&ver=basicenglish">2 Thessalonians</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=1Timothy&ver=cut">提 摩 太 前 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1Timothy&ver=cus">提 摩 太 前 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1Timothy&ver=basicenglish">1 Timothy</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=2Timothy&ver=cut">提 摩 太 後 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2Timothy&ver=cus">提 摩 太 后 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2Timothy&ver=basicenglish">2 Timothy</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Titus&ver=cut">提 多 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Titus&ver=cus">提 多 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Titus&ver=basicenglish">Titus</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Philemon&ver=cut">腓 利 門 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Philemon&ver=cus">腓 利 门 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Philemon&ver=basicenglish">Philemon</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Hebrews&ver=cut">希 伯 來 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Hebrews&ver=cus">希 伯 来 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Hebrews&ver=basicenglish">Hebrews</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=James&ver=cut">雅 各 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=James&ver=cus">雅 各 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=James&ver=basicenglish">James</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=1Peter&ver=cut">彼 得 前 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1Peter&ver=cus">彼 得 前 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1Peter&ver=basicenglish">1 Peter</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=2Peter&ver=cut">彼 得 後 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2Peter&ver=cus">彼 得 后 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2Peter&ver=basicenglish">2 Peter</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=1John&ver=cut">約 翰 一 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1John&ver=cus">约 翰 一 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=1John&ver=basicenglish">1 John</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=2John&ver=cut">約 翰 二 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2John&ver=cus">约 翰 二 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=2John&ver=basicenglish">2 John</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=3John&ver=cut">約 翰 三 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=3John&ver=cus">约 翰 三 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=3John&ver=basicenglish">3 John</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Jude&ver=cut">猶 大 書</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Jude&ver=cus">犹 大 书</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Jude&ver=basicenglish">Jude</a></td>
      </tr>
      <tr class="text-center">
        <td class="border"><a href="/new/thecontent?thebk=Revelation&ver=cut">啟 示 錄</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Revelation&ver=cus">启 示 录</a></td>
        <td class="border"><a href="/new/thecontent?thebk=Revelation&ver=basicenglish">Revelation</a></td>
      </tr>

    </table>
  </div>
</template>

<script>
export default {}
</script>

<style>
</style>