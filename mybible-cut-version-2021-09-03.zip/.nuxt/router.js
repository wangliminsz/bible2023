import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _e554ba48 = () => interopDefault(import('..\\pages\\newindex.vue' /* webpackChunkName: "pages/newindex" */))
const _7dc35551 = () => interopDefault(import('..\\pages\\newindex-cut.vue' /* webpackChunkName: "pages/newindex-cut" */))
const _f4567396 = () => interopDefault(import('..\\pages\\oldindex.vue' /* webpackChunkName: "pages/oldindex" */))
const _10df242a = () => interopDefault(import('..\\pages\\oldindex-cut.vue' /* webpackChunkName: "pages/oldindex-cut" */))
const _45feaf64 = () => interopDefault(import('..\\pages\\new\\thecontent.vue' /* webpackChunkName: "pages/new/thecontent" */))
const _618cffbc = () => interopDefault(import('..\\pages\\new\\thesplash.vue' /* webpackChunkName: "pages/new/thesplash" */))
const _3f1014a8 = () => interopDefault(import('..\\pages\\new\\thetext.vue' /* webpackChunkName: "pages/new/thetext" */))
const _2a5fc945 = () => interopDefault(import('..\\pages\\new\\thetxt.vue' /* webpackChunkName: "pages/new/thetxt" */))
const _6754d5e7 = () => interopDefault(import('..\\pages\\new\\upload.vue' /* webpackChunkName: "pages/new/upload" */))
const _49abd598 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/newindex",
    component: _e554ba48,
    name: "newindex"
  }, {
    path: "/newindex-cut",
    component: _7dc35551,
    name: "newindex-cut"
  }, {
    path: "/oldindex",
    component: _f4567396,
    name: "oldindex"
  }, {
    path: "/oldindex-cut",
    component: _10df242a,
    name: "oldindex-cut"
  }, {
    path: "/new/thecontent",
    component: _45feaf64,
    name: "new-thecontent"
  }, {
    path: "/new/thesplash",
    component: _618cffbc,
    name: "new-thesplash"
  }, {
    path: "/new/thetext",
    component: _3f1014a8,
    name: "new-thetext"
  }, {
    path: "/new/thetxt",
    component: _2a5fc945,
    name: "new-thetxt"
  }, {
    path: "/new/upload",
    component: _6754d5e7,
    name: "new-upload"
  }, {
    path: "/",
    component: _49abd598,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
