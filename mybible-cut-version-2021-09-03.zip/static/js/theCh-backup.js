function getChList(vthisBk) {

    if (vthisBk === 'Matthew') {

        vbooklist01 = [
            { bkno: 1, chno: 25 },
            { bkno: 2, chno: 23 },
            { bkno: 3, chno: 17 },
            { bkno: 4, chno: 25 },
            { bkno: 5, chno: 48 },
            { bkno: 6, chno: 34 },
            { bkno: 7, chno: 29 },
            { bkno: 8, chno: 34 },
            { bkno: 9, chno: 38 },
            { bkno: 10, chno: 42 },
            { bkno: 11, chno: 30 },
            { bkno: 12, chno: 50 },
            { bkno: 13, chno: 58 },
            { bkno: 14, chno: 36 },
            { bkno: 15, chno: 39 },
            { bkno: 16, chno: 28 },
            { bkno: 17, chno: 27 },
            { bkno: 18, chno: 35 },
            { bkno: 19, chno: 30 },
            { bkno: 20, chno: 34 },
            { bkno: 21, chno: 46 },
            { bkno: 22, chno: 46 },
            { bkno: 23, chno: 39 },
            { bkno: 24, chno: 51 },
            { bkno: 25, chno: 46 },
            { bkno: 26, chno: 75 },
            { bkno: 27, chno: 66 },
            { bkno: 28, chno: 20 },
        ]
    }


    if (vthisBk === 'James') {

        vbooklist01 = [
            { bkno: 1, chno: 27 },
            { bkno: 2, chno: 26 },
            { bkno: 3, chno: 18 },
            { bkno: 4, chno: 17 },
            { bkno: 5, chno: 20 },
        ]
    }

    if (vthisBk === "James") {

        vbooklist01 = [
            { bkno: 1, chno: 27 },
            { bkno: 2, chno: 26 },
            { bkno: 3, chno: 18 },
            { bkno: 4, chno: 17 },
            { bkno: 5, chno: 20 },
        ];
    }


    return vbooklist01;

}