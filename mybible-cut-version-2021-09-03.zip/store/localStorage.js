// store/localStorage.js
export const state = () => ({
    anyValues: 100,

})