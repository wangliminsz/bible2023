// store/sessionStorage.js
export const state = () => ({
    anyValues: 900,

    storedBk: '',
    storedVer: '',
    storedCh: '',
    storedVerse: [],

    txtFinal: {},
    imgFinal: '',

})